__global__ void MMScanKernel00(float*, float*, long, long);

__global__ void MMScanKernel01(float*, float*, long, long);

__global__ void MMScanKernel02(float*, float*, float*, long, long);
