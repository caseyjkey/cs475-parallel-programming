__global__ void MMScanKernel00(float*, float*, long, long);
